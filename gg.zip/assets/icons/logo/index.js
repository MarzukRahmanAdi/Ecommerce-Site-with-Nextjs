const Logo = () => {
    return (
<img width={70} src="https://i.ibb.co/v4g1yQj/Screenshot-from-2022-12-29-01-14-46-prev-ui.png" />
    )
  };
  
  
  export default Logo